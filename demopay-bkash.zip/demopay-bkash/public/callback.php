<?php
// bKash redirects the customer here: ?paymentID=...&status=success|failure|cancel
require __DIR__ . '/../bootstrap.php';

$paymentID = $_GET['paymentID'] ?? '';
$status    = $_GET['status'] ?? '';
$order     = $_SESSION['orders'][$paymentID] ?? null;
$result    = ['status' => $status === 'cancel' ? 'Cancelled' : 'Failed'];

if ($order && $status === 'success') {
    try {
        $r = unwrap(bkash()->checkout()->execute($paymentID));
        // Verify with bKash (server-side) before treating it as paid.
        if (($r->transactionStatus ?? '') === 'Completed' && (float)$r->amount == (float)$order['amount']) {
            $result = [
                'status'  => 'Completed',
                'trxID'   => $r->trxID,
                'amount'  => (float)$r->amount,
                'invoice' => $order['invoice'],
            ];
        }
    } catch (Throwable $e) {
        error_log($e->getMessage());
    }
}
unset($_SESSION['orders'][$paymentID]);
$_SESSION['result'] = $result;
header('Location: /index.html?result=1');
