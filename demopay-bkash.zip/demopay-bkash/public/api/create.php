<?php
require __DIR__ . '/../../bootstrap.php';
header('Content-Type: application/json');

function fail(string $m, int $c = 400) { http_response_code($c); echo json_encode(['error' => $m]); exit; }

$in     = json_decode(file_get_contents('php://input'), true) ?: [];
$amount = round((float)($in['amount'] ?? 0), 2);
$phone  = preg_replace('/\D/', '', (string)($in['phone'] ?? ''));

// Never trust the browser: validate here.
if ($amount < 1 || $amount > 10000)        fail('Amount 1 theke 10000 er moddhe dao');
if (!preg_match('/^01\d{9}$/', $phone))    fail('Sothik bKash number dao');

$invoice = 'DP' . strtoupper(bin2hex(random_bytes(5)));
try {
    $res = unwrap(bkash()->checkout()->create(
        '0011',
        rtrim(env_get('APP_URL'), '/') . '/callback.php',
        $phone,
        null,
        number_format($amount, 2, '.', ''),
        $invoice,
        'BDT',
        'sale'
    ));
    if (empty($res->bkashURL) || empty($res->paymentID)) {
        error_log('bKash create failed: ' . json_encode($res));
        fail('bKash payment shuru kora jayni', 502);
    }
    $_SESSION['orders'][$res->paymentID] = ['amount' => $amount, 'invoice' => $invoice];
    echo json_encode(['url' => $res->bkashURL]);
} catch (Throwable $e) {
    error_log($e->getMessage());
    fail('Server error', 500);
}
