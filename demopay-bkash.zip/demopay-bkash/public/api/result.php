<?php
require __DIR__ . '/../../bootstrap.php';
header('Content-Type: application/json');
echo json_encode($_SESSION['result'] ?? ['status' => 'None']);
unset($_SESSION['result']); // read once
