<?php
require __DIR__ . '/vendor/autoload.php';

use Shipu\Bkash\Managers\Tokenized;
use Shipu\Bkash\Enums\BkashKey;

Dotenv\Dotenv::createImmutable(__DIR__)->safeLoad();
session_start();

function env_get(string $k, $d = '') { return $_ENV[$k] ?? getenv($k) ?: $d; }

function bkash(): Tokenized {
    return new Tokenized([
        BkashKey::SANDBOX       => filter_var(env_get('BKASH_SANDBOX', 'true'), FILTER_VALIDATE_BOOLEAN),
        BkashKey::VERSION       => env_get('BKASH_VERSION', 'v1.2.0-beta'),
        BkashKey::APP_KEY       => env_get('BKASH_APP_KEY'),
        BkashKey::APP_SECRET    => env_get('BKASH_APP_SECRET'),
        BkashKey::USER_NAME     => env_get('BKASH_USERNAME'),
        BkashKey::PASSWORD      => env_get('BKASH_PASSWORD'),
        BkashKey::CALL_BACK_URL => rtrim(env_get('APP_URL'), '/') . '/callback.php',
    ]);
}

// The library's responses may be invokable objects, JSON strings or plain objects.
function unwrap($r) {
    if (is_callable($r)) { $r = $r(); }
    if (is_string($r))   { $r = json_decode($r); }
    return $r;
}
