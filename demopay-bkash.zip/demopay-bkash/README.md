# DemoPay + bKash sandbox

1. `composer install`
2. `cp .env.example .env` and fill your bKash SANDBOX credentials
3. `php -S localhost:8003 -t public`
4. Open http://localhost:8003/index.html -> Add Money -> Pay with bKash

Credentials stay in `.env` (server only). Never put them in the HTML.
Callback URL must match what is registered in your bKash sandbox account.
